
import tkinter as tk

def add_contact():
    name = name_entry.get()
    phone = phone_entry.get()
    contact_listbox.insert(tk.END, name + " - " + phone)
    name_entry.delete(0, tk.END)
    phone_entry.delete(0, tk.END)

def clear_fields():
    name_entry.delete(0, tk.END)
    phone_entry.delete(0, tk.END)

def delete_contact():
    selected = contact_listbox.curselection()
    if selected:
        contact_listbox.delete(selected)

root = tk.Tk()
root.title("주소록")

title_label = tk.Label(root, text="주소록")
title_label.pack()

name_entry = tk.Entry(root)
name_entry.pack()

phone_entry = tk.Entry(root)
phone_entry.pack()

add_button = tk.Button(root, text="연락처 추가", command=add_contact)
add_button.pack()

clear_button = tk.Button(root, text="필드 지우기", command=clear_fields)
clear_button.pack()

contact_listbox = tk.Listbox(root)
contact_listbox.pack()

delete_button = tk.Button(root, text="삭제", command=delete_contact)
delete_button.pack()

root.mainloop()
