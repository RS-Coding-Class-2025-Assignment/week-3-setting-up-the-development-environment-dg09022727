
import tkinter as tk

def convert_to_fahrenheit():
    c = celsius_entry.get()
    f = (float(c) * 9/5) + 32
    result_label.config(text="화씨: " + str(round(f, 2)) + " °F")

def convert_to_celsius():
    f = celsius_entry.get()
    c = (float(f) - 32) * 5/9
    result_label.config(text="섭씨: " + str(round(c, 2)) + " °C")

root = tk.Tk()
root.title("온도 변환기")

celsius_entry = tk.Entry(root)
celsius_entry.pack()

convert_button = tk.Button(root, text="섭씨 ➡ 화씨", command=convert_to_fahrenheit)
convert_button.pack()

result_label = tk.Label(root, text="")
result_label.pack()

reverse_button = tk.Button(root, text="화씨 ➡ 섭씨", command=convert_to_celsius)
reverse_button.pack()

root.mainloop()
